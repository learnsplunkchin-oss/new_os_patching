#!/usr/bin/env python3
"""
DNF OS Patching Assessment Generator (Air-Gapped Compatible)
Generates assessment data from pre/post evidence without external dependencies.
"""

import json
import sys
import argparse
from pathlib import Path
from datetime import datetime, timezone


def load_json_evidence(file_path):
    """Load and parse JSON evidence file."""
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return None
    except json.JSONDecodeError as e:
        return {"_parse_error": str(e)}


def extract_package_keys(evidence):
    """Extract package keys from evidence JSON."""
    if not evidence or evidence.get("_parse_error"):
        return set()
    
    packages = evidence.get("packages", [])
    return {pkg["key"] for pkg in packages if isinstance(pkg, dict) and "key" in pkg}


def format_package_display(package):
    """Format package for display: name.arch version (repo)"""
    name = package.get("name", "unknown")
    arch = package.get("arch", "unknown")
    version = package.get("version", "unknown")
    repo = package.get("repo", "unknown")
    return f"{name}.{arch} {version} ({repo})"


def assess_single_host(hostname, pre_evidence, post_evidence, patch_job_evidence):
    """
    Assess patching outcome for a single host.
    
    Returns a dict with:
    - assessment_status: PASS | INCOMPLETE | PATCH FAILED | UPDATES REMAIN
    - evidence_complete: bool
    - precheck: {available, package_count, packages, raw}
    - postcheck: {available, package_count, packages, raw}
    - patch_job: {available, status, raw}
    - comparison: {resolved_count, remaining_count, new_count, resolved_packages, remaining_packages, new_packages}
    - evidence_errors: list of error messages
    """
    
    errors = []
    
    # Precheck assessment
    pre_available = pre_evidence is not None and not pre_evidence.get("_parse_error")
    if pre_evidence and pre_evidence.get("_parse_error"):
        errors.append(f"Precheck JSON parse error: {pre_evidence['_parse_error']}")
    
    pre_packages_keys = extract_package_keys(pre_evidence) if pre_available else set()
    pre_packages_display = []
    if pre_available and pre_evidence:
        pre_packages_display = [
            format_package_display(pkg) 
            for pkg in pre_evidence.get("packages", [])
        ]
    
    # Postcheck assessment
    post_available = post_evidence is not None and not post_evidence.get("_parse_error")
    if post_evidence and post_evidence.get("_parse_error"):
        errors.append(f"Postcheck JSON parse error: {post_evidence['_parse_error']}")
    
    post_packages_keys = extract_package_keys(post_evidence) if post_available else set()
    post_packages_display = []
    if post_available and post_evidence:
        post_packages_display = [
            format_package_display(pkg) 
            for pkg in post_evidence.get("packages", [])
        ]
    
    # Patch job assessment
    patch_job_available = patch_job_evidence is not None and not patch_job_evidence.get("_parse_error")
    patch_job_status = "UNKNOWN"
    if patch_job_available and patch_job_evidence:
        patch_job_status = patch_job_evidence.get("status", "UNKNOWN")
    
    # Evidence completeness
    evidence_complete = pre_available and post_available
    
    # Package comparison
    resolved_keys = pre_packages_keys - post_packages_keys
    remaining_keys = pre_packages_keys & post_packages_keys
    new_keys = post_packages_keys - pre_packages_keys
    
    # Build display lists for comparison
    resolved_packages = []
    remaining_packages = []
    new_packages = []
    
    if pre_available and pre_evidence:
        for pkg in pre_evidence.get("packages", []):
            pkg_key = pkg.get("key")
            display = format_package_display(pkg)
            if pkg_key in resolved_keys:
                resolved_packages.append(display)
            elif pkg_key in remaining_keys:
                remaining_packages.append(display)
    
    if post_available and post_evidence:
        for pkg in post_evidence.get("packages", []):
            pkg_key = pkg.get("key")
            if pkg_key in new_keys:
                new_packages.append(format_package_display(pkg))
    
    # Determine assessment status
    assessment_status = "INCOMPLETE"
    
    if not evidence_complete:
        assessment_status = "INCOMPLETE"
        if not pre_available:
            errors.append("Precheck evidence is missing or invalid")
        if not post_available:
            errors.append("Postcheck evidence is missing or invalid")
    elif patch_job_status == "FAILED":
        assessment_status = "PATCH FAILED"
    elif len(post_packages_keys) == 0 and len(pre_packages_keys) > 0:
        assessment_status = "PASS"
    elif len(post_packages_keys) > 0:
        assessment_status = "UPDATES REMAIN"
    elif len(pre_packages_keys) == 0 and len(post_packages_keys) == 0:
        assessment_status = "PASS"  # No updates needed
    
    # Check for connection failures in evidence
    if pre_evidence and pre_evidence.get("status") in ["CONNECTION_FAILED", "UNEXPECTED_FAILURE"]:
        assessment_status = "INCOMPLETE"
        errors.append(f"Precheck failed: {pre_evidence.get('error_message', 'Connection error')}")
    
    if post_evidence and post_evidence.get("status") in ["CONNECTION_FAILED", "UNEXPECTED_FAILURE"]:
        assessment_status = "INCOMPLETE"
        errors.append(f"Postcheck failed: {post_evidence.get('error_message', 'Connection error')}")
    
    return {
        "host": hostname,
        "assessment_status": assessment_status,
        "evidence_complete": evidence_complete,
        "precheck": {
            "available": pre_available,
            "package_count": len(pre_packages_keys),
            "packages": sorted(pre_packages_display),
            "raw": pre_evidence if pre_available else {}
        },
        "postcheck": {
            "available": post_available,
            "package_count": len(post_packages_keys),
            "packages": sorted(post_packages_display),
            "raw": post_evidence if post_available else {}
        },
        "patch_job": {
            "available": patch_job_available,
            "status": patch_job_status,
            "raw": patch_job_evidence if patch_job_available else {}
        },
        "comparison": {
            "resolved_count": len(resolved_keys),
            "remaining_count": len(remaining_keys),
            "new_count": len(new_keys),
            "resolved_packages": sorted(resolved_packages),
            "remaining_packages": sorted(remaining_packages),
            "new_packages": sorted(new_packages)
        },
        "evidence_errors": errors
    }


def generate_assessment(base_dir, expected_hosts):
    """Generate assessment for all expected hosts."""
    
    base_path = Path(base_dir)
    pre_dir = base_path / "pre"
    post_dir = base_path / "post"
    status_dir = base_path / "status"
    
    reports = []
    summary = {
        "pass": 0,
        "incomplete": 0,
        "patch_failed": 0,
        "updates_remain": 0
    }
    
    for hostname in expected_hosts:
        # Load evidence files
        pre_evidence = load_json_evidence(pre_dir / f"{hostname}.json")
        post_evidence = load_json_evidence(post_dir / f"{hostname}.json")
        patch_job_evidence = load_json_evidence(status_dir / f"{hostname}.json")
        
        # Assess host
        report = assess_single_host(hostname, pre_evidence, post_evidence, patch_job_evidence)
        reports.append(report)
        
        # Update summary
        status = report["assessment_status"]
        if status == "PASS":
            summary["pass"] += 1
        elif status == "PATCH FAILED":
            summary["patch_failed"] += 1
        elif status == "UPDATES REMAIN":
            summary["updates_remain"] += 1
        else:
            summary["incomplete"] += 1
    
    return {
        "assessment": {
            "generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
            "host_count": len(expected_hosts),
            "collector_host": "vm1"  # This should be passed as parameter if needed
        },
        "summary": summary,
        "reports": reports
    }


def main():
    parser = argparse.ArgumentParser(
        description="Generate DNF OS patching assessment from evidence files"
    )
    parser.add_argument("--base-dir", required=True, help="Base directory containing pre/post/status subdirectories")
    parser.add_argument("--expected-hosts", required=True, help="Comma-separated list of expected hostnames")
    parser.add_argument("--output", required=True, help="Output JSON file path")
    parser.add_argument("--collector-host", default="vm1", help="Collector hostname")
    
    args = parser.parse_args()
    
    expected_hosts = [h.strip() for h in args.expected_hosts.split(",") if h.strip()]
    
    if not expected_hosts:
        print("ERROR: No expected hosts provided", file=sys.stderr)
        return 1
    
    assessment_data = generate_assessment(args.base_dir, expected_hosts)
    assessment_data["assessment"]["collector_host"] = args.collector_host
    
    # Write output JSON
    try:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(assessment_data, f, indent=2, ensure_ascii=False)
        print(f"Assessment data written to: {args.output}")
        print(f"Total hosts: {assessment_data['assessment']['host_count']}")
        print(f"PASS: {assessment_data['summary']['pass']}")
        print(f"INCOMPLETE: {assessment_data['summary']['incomplete']}")
        print(f"PATCH FAILED: {assessment_data['summary']['patch_failed']}")
        print(f"UPDATES REMAIN: {assessment_data['summary']['updates_remain']}")
        
        # Return exit code 2 if any issues detected
        if assessment_data['summary']['incomplete'] > 0 or assessment_data['summary']['patch_failed'] > 0:
            return 2
        return 0
    
    except Exception as e:
        print(f"ERROR: Failed to write assessment data: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
