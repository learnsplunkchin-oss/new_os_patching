
#!/usr/bin/env python3
"""
RHEL OS Patching Assessment Generator
=====================================

Purpose:
  1. Read precheck, postcheck and patch-job JSON evidence.
  2. Validate evidence for every expected host.
  3. Compare pre-patch and post-patch package data.
  4. Generate assessment.json.
  5. Render an executive HTML dashboard.
  6. Render an individual HTML report for every expected host.

Designed for central execution on vm1.

Dependencies:
  Python 3.9+
  Jinja2

Exit codes:
  0 = Assessment generated successfully.
  1 = Configuration, input, or rendering error.
  2 = Assessment generated, but one or more hosts have incomplete evidence.

The script deliberately does not mark a host PASS merely because files exist.
It requires recognisable package evidence and a recognised patch-job result.
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import re
import sys

from datetime import datetime
from pathlib import Path
from typing import Any, Optional
from zoneinfo import ZoneInfo

from jinja2 import Environment, FileSystemLoader, select_autoescape


LOG = logging.getLogger("dnf_assessment")

VALID_SUCCESS_STATUSES = {
    "success",
    "successful",
    "ok",
    "passed",
    "pass",
    "completed",
    "complete",
    "succeeded",
    "changed",
    "no_change",
    "no-changes",
    "no_updates",
    "no_updates_required",
}

VALID_FAILURE_STATUSES = {
    "failed",
    "failure",
    "error",
    "unreachable",
    "timeout",
    "timed_out",
    "authentication_failed",
    "auth_failed",
    "denied",
    "cancelled",
    "canceled",
}

PACKAGE_LIST_KEYS = (
    "packages",
    "updates",
    "available_updates",
    "available_packages",
    "upgradable",
    "upgradable_packages",
    "package_updates",
    "update_list",
    "dnf_updates",
    "yum_updates",
    "security_updates",
)

PACKAGE_COUNT_KEYS = (
    "package_count",
    "packages_count",
    "update_count",
    "updates_count",
    "available_update_count",
    "available_updates_count",
    "upgradable_count",
    "total_updates",
)

STATUS_KEYS = (
    "patch_status",
    "job_status",
    "execution_status",
    "result_status",
    "status",
    "state",
    "result",
)

ERROR_KEYS = (
    "error",
    "errors",
    "failure",
    "failed",
    "failure_reason",
    "error_message",
    "msg",
    "message",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Generate central RHEL OS patch assessment reports."
    )

    parser.add_argument(
        "--base-dir",
        default="/tmp/os_patching/current",
        help="Base directory for patch assessment data.",
    )
    parser.add_argument(
        "--pre-dir",
        default=None,
        help="Precheck evidence directory.",
    )
    parser.add_argument(
        "--post-dir",
        default=None,
        help="Postcheck evidence directory.",
    )
    parser.add_argument(
        "--status-dir",
        default=None,
        help="Patch-job status evidence directory.",
    )
    parser.add_argument(
        "--report-dir",
        default=None,
        help="Assessment output directory.",
    )
    parser.add_argument(
        "--template-dir",
        default=None,
        help="Directory containing the HTML Jinja2 templates.",
    )
    parser.add_argument(
        "--expected-hosts",
        default="vm1,vm2,vm3,vm4,vm5,vm6,vm7",
        help="Comma-separated list of expected hosts.",
    )
    parser.add_argument(
        "--title",
        default="RHEL OS Patching Assessment",
        help="Report title.",
    )
    parser.add_argument(
        "--dashboard-template",
        default="os_patch_dashboard.html.j2",
        help="Dashboard template filename.",
    )
    parser.add_argument(
        "--detail-template",
        default="os_patch_detail.html.j2",
        help="Per-host detail template filename.",
    )
    parser.add_argument(
        "--timezone",
        default="Asia/Singapore",
        help="Timezone used for report timestamps.",
    )
    parser.add_argument(
        "--collector-host",
        default="vm1",
        help="Hostname of the central assessment collector.",
    )
    parser.add_argument(
        "--missing-evidence-status",
        default="INCOMPLETE",
        help="Status assigned when evidence is missing or invalid.",
    )
    parser.add_argument(
        "--no-patch-job-status",
        default="UNKNOWN",
        help="Status used when patch-job evidence is absent.",
    )
    parser.add_argument(
        "--failed-patch-status",
        default="FAILED",
        help="Status assigned to a failed patch job.",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=("DEBUG", "INFO", "WARNING", "ERROR"),
        help="Logging verbosity.",
    )

    return parser.parse_args()


def configure_logging(level: str) -> None:
    logging.basicConfig(
        level=getattr(logging, level),
        format="%(asctime)s %(levelname)s %(message)s",
    )


def safe_host_name(host: str) -> str:
    """Reject path separators and unsafe filenames."""
    host = host.strip()

    if not host:
        raise ValueError("Expected host list contains an empty hostname.")

    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", host):
        raise ValueError(f"Invalid hostname for report filename: {host!r}")

    return host


def load_json(path: Path) -> tuple[Optional[Any], Optional[str]]:
    """Load JSON and return a useful error instead of raising."""
    if not path.is_file():
        return None, f"Missing evidence file: {path}"

    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except json.JSONDecodeError as exc:
        return None, (
            f"Invalid JSON in {path}: "
            f"line {exc.lineno}, column {exc.colno}: {exc.msg}"
        )
    except OSError as exc:
        return None, f"Cannot read {path}: {exc}"

    if not isinstance(data, (dict, list)):
        return None, f"Unexpected JSON root type in {path}: {type(data).__name__}"

    if isinstance(data, dict) and not data:
        return None, f"JSON evidence is empty: {path}"

    return data, None


def as_int(value: Any) -> Optional[int]:
    """Convert a non-negative integer-like value to int."""
    if isinstance(value, bool):
        return None

    try:
        number = int(value)
    except (TypeError, ValueError, OverflowError):
        return None

    return number if number >= 0 else None


def normalise_status(value: Any) -> str:
    if value is None:
        return ""

    if isinstance(value, bool):
        return "success" if value else "failed"

    return str(value).strip().lower().replace(" ", "_").replace("-", "_")


def find_first_value(data: Any, keys: tuple[str, ...]) -> Any:
    """
    Find a matching key in a JSON object, including common nested wrappers.

    This intentionally uses a bounded, schema-agnostic search. It does not
    interpret arbitrary numeric values as package counts.
    """
    if isinstance(data, dict):
        for key in keys:
            if key in data and data[key] is not None:
                return data[key]

        for nested_key in ("data", "result", "results", "summary", "facts"):
            nested = data.get(nested_key)
            if isinstance(nested, (dict, list)):
                value = find_first_value(nested, keys)
                if value is not None:
                    return value

    elif isinstance(data, list):
        for item in data:
            value = find_first_value(item, keys)
            if value is not None:
                return value

    return None


def find_package_list(data: Any) -> Optional[list[Any]]:
    """Find a recognisable package list, including common nested structures."""
    if isinstance(data, list):
        # A top-level list may itself be the package list. Each item should
        # normally be an object or a package-name string.
        if all(isinstance(item, (dict, str)) for item in data):
            return data
        return None

    if not isinstance(data, dict):
        return None

    for key in PACKAGE_LIST_KEYS:
        value = data.get(key)
        if isinstance(value, list):
            return value

    for nested_key in ("data", "result", "results", "summary", "facts"):
        nested = data.get(nested_key)
        if isinstance(nested, (dict, list)):
            found = find_package_list(nested)
            if found is not None:
                return found

    return None


def package_name(package: Any) -> str:
    """Extract a stable package identity for comparison."""
    if isinstance(package, str):
        return package.strip()

    if not isinstance(package, dict):
        return str(package)

    name = (
        package.get("name")
        or package.get("package")
        or package.get("package_name")
        or package.get("nevra")
        or package.get("full_name")
    )

    if name:
        version = package.get("version")
        release = package.get("release")
        arch = package.get("arch") or package.get("architecture")

        # Prefer a package identifier that distinguishes versions when
        # the collector provides version metadata.
        if version and release and arch:
            return f"{name}-{version}-{release}.{arch}"
        if version and release:
            return f"{name}-{version}-{release}"
        if version:
            return f"{name}-{version}"

        return str(name).strip()

    # Do not silently compare an object with no package identity.
    return json.dumps(package, sort_keys=True, ensure_ascii=False)


def package_evidence(data: Any) -> dict[str, Any]:
    """
    Extract package data and validate that it is recognisable.

    An explicit package list, including an empty list, is valid evidence.
    A numeric package count is also valid if its key is recognised.
    """
    package_list = find_package_list(data)

    if package_list is not None:
        names = [
            package_name(item)
            for item in package_list
            if package_name(item)
        ]

        return {
            "valid": True,
            "package_count": len(names),
            "packages": names,
            "raw": data,
            "source": "package_list",
            "error": None,
        }

    count_value = find_first_value(data, PACKAGE_COUNT_KEYS)
    count = as_int(count_value)

    if count is not None:
        # The source reports a count but provides no package names.
        # This is useful evidence, but package-level comparison is limited.
        return {
            "valid": True,
            "package_count": count,
            "packages": [],
            "raw": data,
            "source": "package_count",
            "error": None,
        }

    return {
        "valid": False,
        "package_count": None,
        "packages": [],
        "raw": data,
        "source": None,
        "error": (
            "No recognised package list or package-count field was found. "
            "Check the collector's actual JSON schema."
        ),
    }


def extract_status(data: Any) -> tuple[str, str]:
    """Extract a patch-job status and optional error detail."""
    raw_status = find_first_value(data, STATUS_KEYS)
    status = normalise_status(raw_status)

    raw_error = find_first_value(data, ERROR_KEYS)
    error_text = ""

    if raw_error not in (None, "", False, [], {}):
        if isinstance(raw_error, (dict, list)):
            error_text = json.dumps(raw_error, ensure_ascii=False)
        else:
            error_text = str(raw_error).strip()

    if status in VALID_FAILURE_STATUSES:
        return "FAILED", error_text or f"Patch job reported status: {status}"

    if status in VALID_SUCCESS_STATUSES:
        if error_text:
            return "FAILED", error_text
        return "SUCCESS", ""

    if error_text:
        return "FAILED", error_text

    return "UNKNOWN", (
        f"Unrecognised or missing patch-job status: {raw_status!r}"
    )


def evidence_candidates(
    directory: Path,
    host: str,
    kind: str,
) -> list[Path]:
    """Try common evidence filename conventions."""
    candidates = {
        "pre": [
            f"{host}.json",
            f"{host}_pre.json",
            f"{host}-pre.json",
            f"{host}_precheck.json",
            f"{host}-precheck.json",
            f"{host}_dnf_precheck.json",
        ],
        "post": [
            f"{host}.json",
            f"{host}_post.json",
            f"{host}-post.json",
            f"{host}_postcheck.json",
            f"{host}-postcheck.json",
            f"{host}_dnf_postcheck.json",
        ],
        "status": [
            f"{host}.json",
            f"{host}_status.json",
            f"{host}-status.json",
            f"{host}_patch_status.json",
            f"{host}-patch-status.json",
            f"{host}_patch_job.json",
        ],
    }

    return [directory / name for name in candidates[kind]]


def load_host_evidence(
    directory: Path,
    host: str,
    kind: str,
) -> tuple[Optional[Any], Optional[str], Optional[str]]:
    """Load the first existing evidence candidate."""
    paths = evidence_candidates(directory, host, kind)

    for path in paths:
        if path.is_file():
            data, error = load_json(path)
            return data, error, str(path)

    expected = ", ".join(str(path) for path in paths)
    return None, f"Missing {kind} evidence. Tried: {expected}", None


def build_package_comparison(
    pre: dict[str, Any],
    post: dict[str, Any],
) -> dict[str, Any]:
    """
    Compare pre- and post-check package evidence.

    The list-based comparison is only authoritative when both files include
    package lists. Count-only data is not enough to claim specific packages
    were resolved, remaining, or newly introduced.
    """
    result = {
        "comparison_available": False,
        "comparison_method": "unavailable",
        "resolved_count": None,
        "remaining_count": None,
        "new_count": None,
        "resolved_packages": [],
        "remaining_packages": [],
        "new_packages": [],
        "note": "",
    }

    if not pre["valid"] or not post["valid"]:
        result["note"] = "Precheck or postcheck package evidence is invalid."
        return result

    if pre["source"] != "package_list" or post["source"] != "package_list":
        result["note"] = (
            "Only package counts were available, so package-level comparison "
            "cannot be calculated reliably."
        )
        return result

    pre_set = set(pre["packages"])
    post_set = set(post["packages"])

    resolved = sorted(pre_set - post_set)
    remaining = sorted(post_set)
    new = sorted(post_set - pre_set)

    result.update(
        {
            "comparison_available": True,
            "comparison_method": "package_identity_set",
            "resolved_count": len(resolved),
            "remaining_count": len(remaining),
            "new_count": len(new),
            "resolved_packages": resolved,
            "remaining_packages": remaining,
            "new_packages": new,
            "note": (
                "Comparison uses package identities reported by the "
                "precheck and postcheck collectors."
            ),
        }
    )

    return result


def utc_or_local_timestamp(timezone_name: str) -> str:
    try:
        zone = ZoneInfo(timezone_name)
    except Exception as exc:
        raise ValueError(
            f"Invalid timezone {timezone_name!r}: {exc}"
        ) from exc

    return datetime.now(zone).isoformat(timespec="seconds")


def assess_host(
    host: str,
    pre_dir: Path,
    post_dir: Path,
    status_dir: Path,
    generated_at: str,
    missing_status: str,
    no_patch_status: str,
    failed_patch_status: str,
) -> dict[str, Any]:
    errors: list[str] = []

    pre_data, pre_error, pre_file = load_host_evidence(
        pre_dir, host, "pre"
    )
    post_data, post_error, post_file = load_host_evidence(
        post_dir, host, "post"
    )
    status_data, status_error, status_file = load_host_evidence(
        status_dir, host, "status"
    )

    if pre_error:
        errors.append(pre_error)
    if post_error:
        errors.append(post_error)
    if status_error:
        errors.append(status_error)

    if pre_data is not None:
        pre = package_evidence(pre_data)
        if not pre["valid"]:
            errors.append(f"Precheck evidence invalid: {pre['error']}")
    else:
        pre = {
            "valid": False,
            "package_count": None,
            "packages": [],
            "raw": {},
            "source": None,
            "error": pre_error,
        }

    if post_data is not None:
        post = package_evidence(post_data)
        if not post["valid"]:
            errors.append(f"Postcheck evidence invalid: {post['error']}")
    else:
        post = {
            "valid": False,
            "package_count": None,
            "packages": [],
            "raw": {},
            "source": None,
            "error": post_error,
        }

    if status_data is not None:
        patch_status, patch_error = extract_status(status_data)

        if patch_status == "UNKNOWN":
            errors.append(patch_error)
        elif patch_status == "FAILED":
            errors.append(patch_error)
    else:
        patch_status = "UNKNOWN"
        patch_error = status_error or "Patch-job evidence is unavailable."

    comparison = build_package_comparison(pre, post)

    if not comparison["comparison_available"]:
        # Count-only data can still be valid evidence, but it cannot support
        # a package-by-package resolution claim.
        LOG.debug(
            "%s: package comparison unavailable: %s",
            host,
            comparison["note"],
        )

    evidence_complete = (
        pre["valid"]
        and post["valid"]
        and status_data is not None
        and patch_status in ("SUCCESS", "FAILED")
    )

    if not evidence_complete:
        assessment_status = missing_status
    elif patch_status == "FAILED":
        assessment_status = failed_patch_status
    elif comparison["comparison_available"]:
        if comparison["remaining_count"] > 0:
            assessment_status = "UPDATES_REMAIN"
        else:
            assessment_status = "PASS"
    else:
        # The evidence is present, but counts alone cannot establish that
        # package updates were resolved. Avoid a false PASS.
        assessment_status = missing_status
        errors.append(
            "Package-level comparison unavailable; a PASS result cannot "
            "be established from count-only evidence."
        )
        evidence_complete = False

    if patch_status == "SUCCESS" and comparison["comparison_available"]:
        patch_outcome = (
            "Patch job succeeded; package evidence comparison completed."
        )
    elif patch_status == "FAILED":
        patch_outcome = "Patch job failed."
    else:
        patch_outcome = "Patch outcome could not be fully established."

    return {
        "host": host,
        "generated_at": generated_at,
        "assessment_status": assessment_status,
        "evidence_complete": bool(evidence_complete),
        "evidence_errors": errors,
        "evidence_files": {
            "precheck": pre_file,
            "postcheck": post_file,
            "patch_status": status_file,
        },
        "precheck": {
            "available": bool(pre["valid"]),
            "package_count": pre["package_count"],
            "packages": pre["packages"],
            "source": pre["source"],
            "raw": pre["raw"],
        },
        "postcheck": {
            "available": bool(post["valid"]),
            "package_count": post["package_count"],
            "packages": post["packages"],
            "source": post["source"],
            "raw": post["raw"],
        },
        "patch_job": {
            "available": status_data is not None,
            "status": patch_status,
            "configured_status": (
                failed_patch_status
                if patch_status == "FAILED"
                else (
                    "SUCCESS"
                    if patch_status == "SUCCESS"
                    else no_patch_status
                )
            ),
            "message": patch_error,
            "raw": status_data if status_data is not None else {},
        },
        "comparison": comparison,
        "patch_outcome": patch_outcome,
    }


def build_summary(hosts: list[dict[str, Any]]) -> dict[str, int]:
    return {
        "total_hosts": len(hosts),
        "pass": sum(
            1 for host in hosts
            if host["assessment_status"] == "PASS"
        ),
        "incomplete": sum(
            1 for host in hosts
            if host["assessment_status"] == "INCOMPLETE"
        ),
        "patch_failed": sum(
            1 for host in hosts
            if host["assessment_status"] == "FAILED"
        ),
        "updates_remain": sum(
            1 for host in hosts
            if host["assessment_status"] == "UPDATES_REMAIN"
        ),
    }


def write_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    temporary = path.with_suffix(path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)
        handle.write("\n")

    os.replace(temporary, path)


def render_reports(
    assessment: dict[str, Any],
    template_dir: Path,
    report_dir: Path,
    dashboard_template_name: str,
    detail_template_name: str,
) -> list[Path]:
    if not template_dir.is_dir():
        raise FileNotFoundError(
            f"Template directory does not exist: {template_dir}"
        )

    for name in (dashboard_template_name, detail_template_name):
        template_path = template_dir / name
        if not template_path.is_file():
            raise FileNotFoundError(
                f"Required Jinja2 template does not exist: {template_path}"
            )

    env = Environment(
        loader=FileSystemLoader(str(template_dir)),
        autoescape=select_autoescape(
            enabled_extensions=("html", "htm", "xml", "j2"),
            default_for_string=True,
        ),
        trim_blocks=True,
        lstrip_blocks=True,
    )

    dashboard_template = env.get_template(dashboard_template_name)
    detail_template = env.get_template(detail_template_name)

    report_dir.mkdir(parents=True, exist_ok=True)
    written: list[Path] = []

    # Dashboard template context.
    dashboard_html = dashboard_template.render(
        assessment=assessment,
        reports=assessment["hosts"],
        hosts=assessment["hosts"],
        summary=assessment["summary"],
        title=assessment["title"],
        generated_at=assessment["generated_at"],
        collector_host=assessment["collector_host"],
        expected_hosts=assessment["expected_hosts"],
        host_count=assessment["host_count"],
    )

    dashboard_path = report_dir / "os_patching_dashboard.html"
    dashboard_path.write_text(dashboard_html, encoding="utf-8")
    written.append(dashboard_path)

    # One detail report per expected host.
    for report in assessment["hosts"]:
        detail_html = detail_template.render(
            assessment=assessment,
            report=report,
            host=report["host"],
            title=assessment["title"],
            generated_at=assessment["generated_at"],
            summary=assessment["summary"],
        )

        detail_path = report_dir / f"{report['host']}.html"
        detail_path.write_text(detail_html, encoding="utf-8")
        written.append(detail_path)

    return written


def main() -> int:
    args = parse_args()
    configure_logging(args.log_level)

    try:
        base_dir = Path(args.base_dir)
        pre_dir = Path(args.pre_dir) if args.pre_dir else base_dir / "pre"
        post_dir = Path(args.post_dir) if args.post_dir else base_dir / "post"
        status_dir = (
            Path(args.status_dir) if args.status_dir else base_dir / "status"
        )
        report_dir = (
            Path(args.report_dir) if args.report_dir else base_dir / "report"
        )
        template_dir = (
            Path(args.template_dir)
            if args.template_dir
            else base_dir / "templates"
        )

        hosts = [
            safe_host_name(item)
            for item in args.expected_hosts.split(",")
            if item.strip()
        ]

        if not hosts:
            raise ValueError("No expected hosts were configured.")

        if len(hosts) != len(set(hosts)):
            raise ValueError("The expected-host list contains duplicates.")

        generated_at = utc_or_local_timestamp(args.timezone)

        LOG.info("Starting OS patch assessment.")
        LOG.info("Collector host: %s", args.collector_host)
        LOG.info("Expected hosts: %s", ", ".join(hosts))
        LOG.info("Precheck directory: %s", pre_dir)
        LOG.info("Postcheck directory: %s", post_dir)
        LOG.info("Patch status directory: %s", status_dir)
        LOG.info("Report directory: %s", report_dir)
        LOG.info("Template directory: %s", template_dir)

        reports = [
            assess_host(
                host=host,
                pre_dir=pre_dir,
                post_dir=post_dir,
                status_dir=status_dir,
                generated_at=generated_at,
                missing_status=args.missing_evidence_status,
                no_patch_status=args.no_patch_job_status,
                failed_patch_status=args.failed_patch_status,
            )
            for host in hosts
        ]

        summary = build_summary(reports)

        assessment = {
            "title": args.title,
            "generated_at": generated_at,
            "collector_host": args.collector_host,
            "expected_hosts": hosts,
            "host_count": len(reports),
            "summary": summary,
            "hosts": reports,
        }

        json_path = report_dir / "assessment.json"
        write_json(json_path, assessment)
        LOG.info("Wrote assessment JSON: %s", json_path)

        written_reports = render_reports(
            assessment=assessment,
            template_dir=template_dir,
            report_dir=report_dir,
            dashboard_template_name=args.dashboard_template,
            detail_template_name=args.detail_template,
        )

        for path in written_reports:
            LOG.info("Generated report: %s", path)

        LOG.info(
            "Assessment summary: total=%d pass=%d incomplete=%d "
            "patch_failed=%d updates_remain=%d",
            summary["total_hosts"],
            summary["pass"],
            summary["incomplete"],
            summary["patch_failed"],
            summary["updates_remain"],
        )

        incomplete = (
            summary["incomplete"] > 0
            or summary["patch_failed"] > 0
            or summary["updates_remain"] > 0
        )

        if incomplete:
            LOG.warning(
                "Assessment generated, but one or more hosts require review."
            )
            return 2

        LOG.info("All expected hosts passed the assessment.")
        return 0

    except Exception as exc:
        LOG.exception("Assessment generation failed: %s", exc)
        return 1


if __name__ == "__main__":
    sys.exit(main())
